//
//  LoginAndPassword.swift
//  Navigation
//
//  Created by Maksim Maiorov on 17.03.2022.
//

import Foundation

struct User { // ЛОГИН и ПАРОЛЬ
    var login: String
    var password: String
}
