//
//  Post.swift
//  Navigation
//
//  Created by Maksim Maiorov on 09.02.2022.
//

import UIKit

struct Post { // ПОСТ
    var title: String
}
