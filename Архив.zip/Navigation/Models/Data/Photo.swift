//
//  Photo.swift
//  Navigation
//
//  Created by Maksim Maiorov on 28.02.2022.
//

import Foundation

struct Cars { // ФОТО МАШИН
    var image: String
}
