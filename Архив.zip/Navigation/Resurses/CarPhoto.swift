//
//  CarPhoto.swift
//  Navigation
//
//  Created by Maksim Maiorov on 28.02.2022.
//

import Foundation

// Хранилище фото машин

let carImage: [Cars] = [
    Cars(image: "5"),
    Cars(image: "6"),
    Cars(image: "7"),
    Cars(image: "8"),
    Cars(image: "9"),
    Cars(image: "10"),
    Cars(image: "11"),
    Cars(image: "12"),
    Cars(image: "13"),
    Cars(image: "14"),
    Cars(image: "15"),
    Cars(image: "16"),
    Cars(image: "17"),
    Cars(image: "18"),
    Cars(image: "19"),
    Cars(image: "20"),
    Cars(image: "21"),
    Cars(image: "22"),
    Cars(image: "23"),
    Cars(image: "24")
]
